#include<stdio.h>
#include "hellomake.h"

void myPrintHelloMake()
{
    printf("Hello MakeFile");
}