 //1803108
 #include<math.h>
  int main()
  {
    float a=1;
    float b=2;
    float c=a+b;
    return 0;
  }